/* --------------------------------------------------------------- */
/* Licensed Materials - Property of IBM                            */
/* 5724-S84                                                        */
/* (C) Copyright IBM Corp. 2007,2008, All Rights Reserved          */
/* US Government Users Restricted Rights - Use, duplication or     */
/* disclosure restricted by GSA ADP Schedule Contract with         */
/* IBM Corp.                                                       */
/* --------------------------------------------------------------- */
/* PROLOG END TAG zYx                                              */

// Kirkpatrick-Stoll 250 random number generator prototypes

#ifndef _MC_RAND_KS_H_
#define _MC_RAND_KS_H_

//
//  C++ interface
//
#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

// Initialization routine
void mc_rand_ks_init( unsigned int seed );

// Return single vectors of RNGs
vector unsigned int mc_rand_ks_u4( void );
vector float mc_rand_ks_0_to_1_f4( void );
vector float mc_rand_ks_minus1_to_1_f4( void );
vector double mc_rand_ks_0_to_1_d2( void );
vector double mc_rand_ks_0_to_1_d2e( void );
vector double mc_rand_ks_minus1_to_1_d2( void );
vector double mc_rand_ks_minus1_to_1_d2e( void );

// Return more than one vector of RNGs
void mc_rand_ks_array_u4(unsigned int, vector unsigned int *);
void mc_rand_ks_0_to_1_array_f4(unsigned int, vector float *);
void mc_rand_ks_minus1_to_1_array_f4(unsigned int, vector float *);
void mc_rand_ks_0_to_1_array_d2(unsigned int, vector double *);
void mc_rand_ks_0_to_1_array_d2e(unsigned int, vector double *);
void mc_rand_ks_minus1_to_1_array_d2(unsigned int, vector double *);
void mc_rand_ks_minus1_to_1_array_d2e(unsigned int, vector double *);
//
//  C++ interface
//
#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif
